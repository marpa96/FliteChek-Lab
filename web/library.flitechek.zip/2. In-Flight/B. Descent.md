# Descent

> **Approx. Completion Time:** 2 Minutes
> **Purpose:** Prepare for Approach

> [!IMPORTANT]
> Complete to initiate descent

**Owner:** Pablo Martinez
**Applies to:** C172S VFR
**Revision:** 0.1  
**Last updated:** 2026-08-02  
**Source of Truth:** [C172S POH § 4-16](https://www.befa.org/wp-content/uploads/2019/12/POH-Cessna-172S.pdf)

---
## Canon Checklist
> [!Caution]
> **Disconnect Autopilot** before reducing power otherwise you will slow down instead of descending
- [ ] **Power** - Set **AS DESIRED** to achieve smooth descent
- [ ] **Mixture** - **Adjust** for smooth operation (full rich for idle Power)
- [ ] **Altimeter** - **Set**/crosscheck
- [ ] **NAV/GPS** Switch - **SET**
- [ ] **Fuel Selector Valve** - **BOTH**
- [ ] Wing **Flaps** - AS DESIRED (**Vs1 - 110 KIAS, Vs2-3 85 KIAS**)

<!-- flitechek-id: 000008 -->
